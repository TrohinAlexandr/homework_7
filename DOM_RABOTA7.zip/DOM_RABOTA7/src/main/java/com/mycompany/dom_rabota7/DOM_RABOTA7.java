/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dom_rabota7;

/**
 *
 * @author User
 */
import java.util.Scanner;

public class DOM_RABOTA7 {
    public static void main(String[] args) {
        System.out.println("Трохин Александр Андреевич");
        System.out.println("Группа РИБО-01-21  Вариант 4");

        Thread t1 = new Thread(new MyThread(), "Thread-0");
        Thread t2 = new Thread(new MyThread(), "Thread-1");

        t1.start();
        t2.start();

        new Scanner(System.in).nextLine();

        t1.interrupt();
        t2.interrupt();
    }
}