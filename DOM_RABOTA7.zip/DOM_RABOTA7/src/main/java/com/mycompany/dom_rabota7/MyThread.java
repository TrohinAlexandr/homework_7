package com.mycompany.dom_rabota7;

public class MyThread implements Runnable {
    private static int turn = 0;

    private final int id;

    public MyThread() {
        this.id = turn++;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            synchronized (MyThread.class) {
                try {
                    while (id != turn % 2) {
                        MyThread.class.wait();
                    }
                    System.out.println(Thread.currentThread().getName());
                    Thread.sleep(1000);
                    turn++;
                    MyThread.class.notifyAll();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }
}
